// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vregfile___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vregfile___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vregfile___024root__traceDeclTypesSub0(tracep);
}
